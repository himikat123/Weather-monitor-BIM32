# openweathermap.org-ESP8266
ESP8266 parsing library for openweathermap.org site 

UPDATE HISTORY.
11/02/2019:
  fix issue "current weather conditions appears empty".
05/15/2019:
  minor bug fix in void OWMrequest::doUpdate() method
